package com.example.egz2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button button;
    TextView textView;
    EditText email;
    EditText haslo;
    EditText powtorz;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.button2);
        textView = findViewById(R.id.textView3);
        email = findViewById(R.id.editTextEmail);
        haslo = findViewById(R.id.editTextPassword);
        powtorz = findViewById(R.id.editTextRepeatPassword);
    }
    public void conditions(View v){
        boolean at = email.getText().toString().contains("@");
        boolean passwords = haslo.getText().toString().equals(powtorz.getText().toString());
        if(at == false)
            textView.setText("Nieprawidłowy adres e-mail");
        else if(passwords == false)
            textView.setText("Hasła się różnią");
        else
            textView.setText("Witaj " + email.getText().toString());
    }
}




